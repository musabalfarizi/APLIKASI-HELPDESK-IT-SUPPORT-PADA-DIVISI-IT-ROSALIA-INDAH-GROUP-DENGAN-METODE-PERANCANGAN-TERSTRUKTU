<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-07 09:05:22 --> Severity: Notice  --> Undefined property: stdClass::$aktif C:\xampp\htdocs\itdev\admin\application\controllers\Access.php 50
ERROR - 2015-09-07 09:05:22 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\itdev\admin\application\controllers\Access.php 26
ERROR - 2015-09-07 09:16:17 --> Severity: Notice  --> Undefined property: stdClass::$aktif C:\xampp\htdocs\itdev\admin\application\controllers\Access.php 50
ERROR - 2015-09-07 09:16:17 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\itdev\admin\application\controllers\Access.php 26
ERROR - 2015-09-07 09:24:28 --> Severity: Notice  --> Undefined property: stdClass::$aktif C:\xampp\htdocs\itdev\admin\application\controllers\Access.php 50
ERROR - 2015-09-07 09:24:28 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\itdev\admin\application\controllers\Access.php 26
