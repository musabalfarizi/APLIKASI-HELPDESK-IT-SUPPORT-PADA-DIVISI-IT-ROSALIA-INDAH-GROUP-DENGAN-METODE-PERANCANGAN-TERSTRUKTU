<?php
class Orderall extends CI_Model{
function __construct(){
parent::__construct();
}

	function order_all()
	{
		$query=$this->db->query("select id,pemesan,email,telp,company,divisi,read from xorder where read='false' UNION select id,pemesan,email,telp,company,software,terbaca from xorderpro where terbaca='false'");
		
		return $query;
	}
	
	function order_hardware()
	{
		$query=$this->db->query("select id,pemesan,email,telp,company,divisi from xorder where read='false' ");
		
		return $query;
	}
	
	function order_software()
	{
		$query=$this->db->query("SELECT xorderpro.id, xorderpro.kode, xorderpro.pemesan, xorderpro.email, xorderpro.tgl, xorderpro.telp, xorderpro.company, xorderpro.software, xorderpro.request, xorderpro.terbaca, xorderpro.ket, xorderpro.ref_status, mstatus.nama as nama_status, msoftware.nama as nama_software
FROM xorderpro LEFT JOIN msoftware ON xorderpro.software=msoftware.kode
LEFT JOIN mstatus
ON xorderpro.ref_status=mstatus.kode where terbaca='false'");
		
		return $query;
	}

}