<?php

class Kontak extends CI_Model {

	function __construct() {
	parent::__construct();
	
	}
	
public function get_kontak() {
	$query=$this->db->query("SELECT * from xcontactus order by tgl desc");
	return $query->result();
	
}

public function get_kontak_id($id) {
	$this->db->where('id',$id);
	return $this->db->get('xcontactus');
	}
	
function update($id,$person) {
	$this->db->where('id',$id);
	$this->db->update('xcontactus',$person);
}
	
public function delete($id) {
	$this->db->where('id',$id);
	$this->db->delete('xcontactus');
	}
	
public function hitung() {
	$this->db->where('terbaca','f');
	$this->db->from('xcontactus');
	return $query=$this->db->get();
	
	}

	public function asd() {
	
	$query=$this->db->query("SELECT * from xcontactus where terbaca='f' order by id desc");
	return $query;
	}	
	
	public function get_kontak_readed() {
	$query=$this->db->query("SELECT * from xcontactus where terbaca='false' order by id desc");
	return $query;
	
}

	function view($id)
	{
		$this->db->query("update xcontactus set terbaca = 'true' where id = '$id'");
		return true;
	}
}