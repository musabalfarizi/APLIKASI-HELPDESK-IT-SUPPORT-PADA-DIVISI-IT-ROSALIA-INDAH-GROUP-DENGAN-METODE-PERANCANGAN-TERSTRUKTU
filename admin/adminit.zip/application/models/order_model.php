<?php
class Order_model extends CI_Model{

private $primary_key='id';
private $table_name='xorderpro';

function __construct(){
parent::__construct();
}

function get_user_all()
{
$query=$this->db->query("SELECT xorderpro.id, xorderpro.kode, xorderpro.pemesan, xorderpro.email, xorderpro.tgl, xorderpro.telp, xorderpro.company, xorderpro.software, xorderpro.request, xorderpro.terbaca, xorderpro.ket, xorderpro.ref_status, mstatus.nama as nama_status, msoftware.nama as nama_software
FROM xorderpro LEFT JOIN msoftware ON xorderpro.software=msoftware.kode
LEFT JOIN mstatus
ON xorderpro.ref_status=mstatus.kode");
return $query->result();
}
function get_status_id()
	{
	$query=$this->db->query("SELECT * FROM mstatus");
	return $query->result();
	}
function get_software_id()
	{
	$query=$this->db->query("SELECT * FROM msoftware order by kode asc");
	return $query->result();
	}
	
function save($order)
{
$this->db->insert($this->table_name,$order);
return $this->db->insert_id();
}

function get_by_id($id){
$query=$this->db->query("select xorderpro.id, xorderpro.tgl, xorderpro.pemesan, xorderpro.email, xorderpro.telp, xorderpro.company, xorderpro.software, xorderpro.software, xorderpro.request, xorderpro.ket, xorderpro.ref_status, msoftware.kode, msoftware.nama as softwarenya, mstatus.kode, mstatus.nama as statusnya from xorderpro join mstatus on mstatus.kode=xorderpro.ref_status left join msoftware on msoftware.kode=xorderpro.software where xorderpro.id='$id'");
return $query;
}

function update($id,$order) {
$this->db->where($this->primary_key,$id);
$this->db->update($this->table_name,$order);
}

function view($id) {
$this->db->query("update xorderpro set terbaca = 'true' where id = '$id'");
return true;
} 

function delete($id) {
$this->db->where($this->primary_key,$id);
$this->db->delete($this->table_name);
}


public function hitung() {
	
	$this->db->where('terbaca','f');
	$this->db->from('xorderpro');
	return $query=$this->db->get();
	}
	

public function asd() {
	
	
	$query=$this->db->query("SELECT * FROM xorderpro where terbaca='f' order by id desc");
	return $query;
	
}	
}
?>