<?php
Class User extends CI_Model
{
	function login($username,$password)
	{
		$this->db->select('tuser.id,tuser.nama,date(tuser.datei) as since,tuser.pass,tuser.ref_level,tlevel.kode,tlevel.nama as level');
		$this->db->from('tuser');
		$this->db->join('tlevel', 'tlevel.kode = tuser.ref_level');
		$this->db->where('tuser.aktif','true');
		$this->db->where('tuser.nama',$username);
		$this->db->where('pass',md5($password));
		$this->db->limit(1);
		
		$query = $this->db->get();
		
		if($query->num_rows()===1)
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}
	
}
?>