<html>
<head><title>Simple login</title>
</head>
<body>
<link href="<?php echo base_url();?>style/template/1/3.css" rel="stylesheet" type="text/css"/>
<h1 align='center'>Home</h1>
<h2 align='center'>Welcome  <?php echo $username;?>!</h2>
<div><a href="siswa">Lihat daftar siswa</a></div><br/>
</body>
</html>